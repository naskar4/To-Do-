from django.http import HttpResponse
from django.shortcuts import render
def home(request):
    #return HttpResponse("<h1>this is home page<h1>")
    return render(request,'home.html')
def about(request):
    #return HttpResponse('<h1> this is about page<h1>')   
    return render(request,'about.html')
def contact(request):
    #return HttpResponse("<h1>This is Contact page<h1>")
    return render(request,'contact.html')
def gallery(request):
    return HttpResponse("<h1>This is gallery page<h1>")
def footer(request):
    return render(request,'footer.html')     