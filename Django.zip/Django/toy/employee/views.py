from django.shortcuts import render,redirect

from django.http import HttpResponse
from employee.models import *

# Create your views here.

def home(request):
    x=Employee.objects.all()
    return render(request,'employee/home.html',{'a':x})
    #return render(request,'employee/home.html')

def add_employee(request):
    try:
        if request.method=="POST":
            x=Employee()
            x.name=request.POST['name']
            x.email=request.POST['email']
            x.password=request.POST['Password']
            x.address=request.POST['address']
            x.save()
            return redirect('/employee/home/')
        else:
            return render(request,"employee/add_employee.html")
    except Exception as e:
        return HttpResponse(e)            
    #jls_extract_var = 'employee/add_employee.html'
    #return render(request,'employee/add_employee.html')

def delete_employee(request,id):
    d=Employee.objects.get(id=id)
    d.delete()
    return redirect("/employee/home/")
