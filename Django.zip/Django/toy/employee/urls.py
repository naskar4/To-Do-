from django.contrib import admin
from django.urls import path,include 
from .views import *

urlpatterns = [
    path('home/',home),
    path('add_employee/',add_employee),
    path('delete_employee/<int:id>',delete_employee),
    
]