from django.contrib import admin
from .models import *
# from .models import Employee
# from .models import Contact


# Register your models here.
class EmpAdmin(admin.ModelAdmin):
    list_display=('name','email','password','address')
    list_editable=['email']
admin.site.register(Employee,EmpAdmin)

# admin.py
class EmpContact(admin,ModelAdmin):
    list_display=('name','emial','phone','address')
    list_editable=('phone')


# Register your model class with the admin site
admin.site.register(Contact)



